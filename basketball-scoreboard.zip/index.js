let homeAddEl = document.getElementById("home-score")
let guestAddEl = document.getElementById("guest-score")

let increaseHomePointOne = document.getElementById("home-Point-1")
let increaseHomePointTwo = document.getElementById("home-Point-2")
let increaseHomePointThree = document.getElementById("home-Point-3")
let resetHomeScore = document.getElementById("reset-home-score");

let increaseGuestPointOne = document.getElementById("guest-Point-1")
let increaseGuestPointTwo = document.getElementById("guest-Point-2")
let increaseGuestPointThree = document.getElementById("guest-Point-3")
let resetGuestScore = document.getElementById("reset-guest-score");

increaseHomePointOne.addEventListener("click", function () {
  homeAddEl.textContent++;
});
increaseHomePointTwo.addEventListener("click", function () {
  homeAddEl.textContent = Number(homeAddEl.textContent) + 2;
});

increaseHomePointThree.addEventListener("click", function () {
  homeAddEl.textContent = Number(homeAddEl.textContent) + 3;
});
resetHomeScore.addEventListener("click", function () {
  homeAddEl.textContent = 0;
});
increaseGuestPointOne.addEventListener("click",function(){
    guestAddEl.textContent++;
});
increaseGuestPointTwo.addEventListener("click",function(){
    guestAddEl.textContent= Number(guestAddEl.textContent) + 2;
});
increaseGuestPointThree.addEventListener("click",function(){
    guestAddEl.textContent = Number(guestAddEl.textContent) + 3;
});
resetGuestScore.addEventListener("click",function(){
    guestAddEl.textContent = 0;
});
